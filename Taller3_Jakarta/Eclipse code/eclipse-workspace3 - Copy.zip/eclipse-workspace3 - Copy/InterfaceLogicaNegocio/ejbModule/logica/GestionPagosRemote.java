package logica;

import jakarta.ejb.Remote;

@Remote
public interface GestionPagosRemote {

}
