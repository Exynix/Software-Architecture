package logica;

import jakarta.ejb.Stateless;


@Stateless
public class GestionPagos implements GestionPagosRemote {

 
    public GestionPagos() {
        // TODO Auto-generated constructor stub
    }

}
